package test;

public class RunTests
{
  public static int pass,fail,count;
  
  public static void main(String[] args) {
    pass=fail=0;
    int tcount=0;
    for(int i=0;i<args.length;i++) {
      Runnable r = null;
      try {
	r = (Runnable)(Class.forName(args[i]).newInstance());
      } catch(Exception ex) {
	ex.printStackTrace();
      }
      
      count=0;
      r.run();
      tcount+=count;
    }
    
    System.out.println("\nPassed "+pass+", failed "+fail+" out of "+tcount+" tests\n");
    
    // finally exit with the return code set to the number of failures
    System.exit(fail);
  }
  
  public static void section(String s) {
    System.out.println("\n     "+s);
  }
  
  public static void result(Object test,
			    String title,
			    boolean result) {
    result(test,title,result,null,null);
  }
  
  public static void result(Object test,
			    String title,
			    boolean result,
			    String passString,
			    String failString
			    ) {
    count++;
    System.out.println(fix(count)+" "+(result?"PASS":"FAIL")+" "+title);
    String s = (result?passString:failString);
    if(s!=null && s.length()>0)
      System.out.println("          "+s);
    
    if(result)
      pass++;
    else
      fail++;
  }
  
  public static void result(Object test,String title,
			    double left,double right,double tolerance) {
    double d = Math.abs(left-right);
    result(test,title,d<=tolerance,"","Got "+left+" should be "+right);
  }
  
  public static String fix(int c) {
    String s = "00000"+c;
    return s.substring(s.length()-4);
  }
}
