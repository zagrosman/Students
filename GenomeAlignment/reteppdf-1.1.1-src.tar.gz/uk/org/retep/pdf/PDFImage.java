package uk.org.retep.pdf;

import java.awt.Image;
import java.awt.image.*;
import java.io.*;
import java.util.*;

/**
 * This implements the Image XObject
 */
public class PDFImage extends PDFStream implements ImageObserver, Serializable
{
  // the height of the object
  private int width,height;
  private Image img;
  private PixelGrabber grab;
  private int[] pixels;
  
  private String name;
  
  public PDFImage()
  {
    super("/XObject");
  }
  
  public PDFImage(Image img) {
    this();
    setImage(img,0,0,img.getWidth(this),img.getHeight(this),this);
  }
  
  public PDFImage(Image img,int x,int y,int w,int h,ImageObserver obs) {
    this();
    setImage(img,x,y,w,h,obs);
  }
  
  public void setName(String n) {
    name = n;
  }
  
  public String getName() {
    return name;
  }
  
  public void setImage(Image img,int x,int y,int w,int h,ImageObserver obs) {
    pixels = new int[w*h];
    this.img = img;
    width  = w;
    height = h;
    grab = new PixelGrabber(img,x,y,w,h,pixels,0,w);
    grab.startGrabbing();
  }
  
  /**
   * @param os OutputStream to send the object to
   * @exception IOException on error
   */
  public void write(OutputStream os) throws IOException
  {
    writeStart(os);
    
    // write the extra details
    os.write("/Subtype /Image\n/Name ".getBytes());
    os.write(name.getBytes());
    os.write("\n/Width ".getBytes());
    os.write(Integer.toString(width).getBytes());
    os.write("\n/Height ".getBytes());
    os.write(Integer.toString(height).getBytes());
    os.write("\n/BitsPerComponent 8\n/ColorSpace /DefaultRGB\n".getBytes());
    
    // write the pixels to the stream
    System.err.println("Grab status: "+grab.status());
    System.err.println("Processing image "+width+"x"+height+" pixels");
    //while(grab.status()!=ImageObserver.ALLBITS) {
    //}
    ByteArrayOutputStream bos = getStream();
    byte pix[] = new byte[3*width];	// 1 scan line in bytes
    int p;				// scratch pixel
    int i=0;				// position in pixels array
    for(int y=0;y<height;y++) {
      System.err.print("\rProcessing line "+y+"/"+height);
      System.err.flush();
      int o=0;				// position in pix array
      for(int x=0;x<width;x++) {
	p = pixels[i++];
	pix[o++] = (byte)((p&0xff0000)>>16);	// Red
	pix[o++] = (byte)((p&  0xff00)>>8);	// Green
	pix[o++] = (byte)( p&    0xff);		// Blue
      }
      bos.write(pix);
    }
    System.err.println("Processing done");
    
    // this will write the actual stream
    setDeflate(true); // we are binary data!
    writeStream(os);
    
    // Note: we do not call writeEnd() on streams!
  }
  
  public boolean imageUpdate(Image img,int infoflags,int x,int y,int w,int h) {
    System.err.println("img="+img+"\ninfoflags="+infoflags+"\nx="+x+" y="+y+" w="+w+" h="+h);
    //if(img == this.img) {
    if(infoflags==ImageObserver.WIDTH)
      width = w;
    if(infoflags==ImageObserver.HEIGHT)
      height = h;
    
    //return true;
    //}
    return false;
  }
}
