#!/bin/bash
python -u swissdock_daemon.py